<template>
         <!--众筹-->
        <div class=" w100 bg42 column column9 tac p30 fs16 crw">
                立刻发起众筹梦想，将你的独特创意分享给更多的人
             <a href="" target="_blank" class="btn bgw cr42 br4 ml20 bghr1 bchrtran crhr9">发起众筹</a>
         </div> 

</template>