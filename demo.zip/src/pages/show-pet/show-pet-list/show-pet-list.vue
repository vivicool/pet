<template>
    <div>
        <!--晒宠列表-->
        <p>
            我是晒宠页面
        </p>
    </div>
</template>

<style scoped>
    div{
        padding: 100px 0;
    }
  p{
        font-size: 22px;
        text-align: center;
        line-height: 32px;
    }
</style>