<template>
    <div>
        <div class=" clearfix ptb30">
            <h3 class="fl">{{ title }}</h3>
            <div class="fr mt20">
                <a href=""  class="cr43 fs16 pr50 crhr43">猫咪</a>
                <a href=""  class="fs16 cr7 crhr43">狗狗</a>
            </div>
        </div>        
    </div>
</template>

<script>
    export default {
        props:[
            'title'
        ]
    }

</script>