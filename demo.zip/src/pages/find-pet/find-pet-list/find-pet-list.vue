<template>
    <div>
        <div class="container">
            <div class="row mtb50">
               <div class="col-sm-8">
                   <div class="mlr10all">
                        <a class="btn bdn on crw plr25 ptb6 bg43 fs16">不限宠物</a>
                        <a class="btn bc2 bss cr7 plr25 ptb6 bghr43 fs16">领养猫咪</a>
                        <a class="btn bc2 bss cr7 plr25 ptb6 bghr43 fs16">领养狗狗</a>
                   </div>
               </div>
               <div class="col-sm-4">
                   <div  class="cr7-a fs16 crhr43">
                       <ul class="flall pr28all">  
                            <li>
                                 <a href="">选择地址 <i class="iconfont fs18 fwb">&#xe756;</i></a>
                                 <div><a class="bb2 bss bc43 bg43 w60px mt5 dib" v-show="true"></a></div>
                            </li>                                                                                                                                                  
                       </ul>                      
                   </div>
               </div>               
            </div>  
        </div>           
    </div>
</template>