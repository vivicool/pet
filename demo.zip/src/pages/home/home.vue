<template>
    <div>
        <div>       
            <HomeColumn></HomeColumn>
            <HomeBbs></HomeBbs>
            <HomeShowPet></HomeShowPet>
            <HomeExposure></HomeExposure>
            <HomeAdopt></HomeAdopt>
            <HomeCrowdFunding></HomeCrowdFunding>
            <HomeDonation></HomeDonation>
            <HomeRentPet></HomeRentPet>
            <HomeBuyPet></HomeBuyPet>
            <HomeBuyProduct></HomeBuyProduct>
            <HomePetWallpaper></HomePetWallpaper>
            <HomeFunnyVideo></HomeFunnyVideo>
            <HomeFindPet></HomeFindPet>
            <HomePetEncyclopedias></HomePetEncyclopedias>
            <HomePetCommonSense></HomePetCommonSense>
            <HomePetNews></HomePetNews>
            <HomeUserRanking></HomeUserRanking>
            <HomeLeftNav></HomeLeftNav>
            

        </div>    
    </div>
</template>

<script>
import HomeBbs from '../home/home-components/home-bbs.vue'
import HomeColumn from '../home/home-components/home-column.vue'
import HomeShowPet from '../home/home-components/home-show-pet.vue'
import HomeExposure from '../home/home-components/home-exposure.vue'
import HomeAdopt from '../home/home-components/home-adopt.vue'
import HomeCrowdFunding from '../home/home-components/home-crowd-funding.vue'
import HomeDonation from '../home/home-components/home-donation.vue'
import HomeRentPet from '../home/home-components/home-rent-pet.vue'
import HomeBuyPet from '../home/home-components/home-buy-pet.vue'
import HomeBuyProduct from '../home/home-components/home-buy-product.vue'
import HomePetWallpaper from '../home/home-components/home-pet-wallpaper.vue'
import HomeFunnyVideo from '../home/home-components/home-funny-video.vue'
import HomeFindPet from '../home/home-components/home-find-pet.vue'
import HomePetEncyclopedias from '../home/home-components/home-pet-encyclopedias.vue'
import HomePetCommonSense from '../home/home-components/home-pet-common-sense.vue'
import HomePetNews from '../home/home-components/home-pet-news.vue'
import HomeUserRanking from '../home/home-components/home-user-ranking.vue'
import HomeLeftNav from '../home/home-components/home-left-nav.vue'


export default {
    components: {
        HomeColumn,
        HomeBbs,
        HomeShowPet,
        HomeExposure,
        HomeAdopt ,
        HomeCrowdFunding,
        HomeDonation,
        HomeRentPet,
        HomeBuyPet,
        HomeBuyProduct ,
        HomePetWallpaper,
        HomeFunnyVideo,
        HomeFindPet,
        HomePetEncyclopedias,
        HomePetCommonSense,
        HomePetNews,
        HomeUserRanking,
        HomeLeftNav
    }
}
</script>