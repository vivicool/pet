<template>
    <div>
        <!--晒宠详情-->
    </div>
</template>